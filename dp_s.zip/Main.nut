function sqr_main() {
    print("DP-S插件已加载");

    //初始化自动重载
    GameManager.OpenHotFix("/dp_s/MyProject");
}